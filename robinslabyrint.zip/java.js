// 1

var bana = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,1,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,2,2,2,2,2,2,0,2,2,2,2,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,1,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,2,2,1,2,2,2,2,2,2,2,2,2,2,1],
    [1,1,1,2,1,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
]

function draWorld() {
    for(var y = 0; y < bana.length; y=y+1){
        for(var x=0; x < bana[y].length; x=x+1){

            if(bana[y][x] ===0){

                document.getElementById("spelruta").innerHTML += "<img src='monster.png' class='monster'>";
            }
            if(bana[y][x] ===1){

                document.getElementById("spelruta").innerHTML += "<img src='wall.png' class='wall'>";
           
            }
         else  if(bana[y][x] ===2){

                document.getElementById("spelruta").innerHTML += "<div class='marken'></div>";
            }
            else  if(bana[y][x] ===3){

                document.getElementById("spelruta").innerHTML += "<img src='cat.png' class='cat'>";
            }



        }
        document.getElementById("spelruta").innerHTML += "<br>"
    }
}

draWorld();